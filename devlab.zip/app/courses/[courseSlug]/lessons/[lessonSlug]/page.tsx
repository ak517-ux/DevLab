import fs from "fs";
import path from "path";
import { LessonRenderer } from "@/components/lesson/LessonRenderer";

export default function LessonPage({ params }: { params: { courseSlug: string, lessonSlug: string } }) {
  console.log("PARAMS:", params);

  const { courseSlug, lessonSlug } = params;

  if (!courseSlug || !lessonSlug) {
    return (
      <div className="p-10 text-red-400 text-xl">
        Ошибка: параметры маршрута не переданы.
      </div>
    );
  }

  const lessonPath = path.join(
    process.cwd(),
    "courses",
    courseSlug,
    "lessons",
    `${lessonSlug}.json`
  );

  console.log("LESSON PATH:", lessonPath);

  if (!fs.existsSync(lessonPath)) {
    return (
      <div className="p-10 text-red-400 text-xl">
        Ошибка: урок {lessonSlug} не найден. Файл не существует: {lessonPath}
      </div>
    );
  }

  const raw = fs.readFileSync(lessonPath, "utf8");
  const lesson = JSON.parse(raw);

  return (
    <div className="max-w-4xl mx-auto py-16 px-6">
      <h1 className="text-3xl font-bold text-slate-100 mb-10">
        {lesson.title}
      </h1>

      <LessonRenderer lesson={lesson} />
    </div>
  );
}
