import fs from "fs";
import path from "path";
import Link from "next/link";

export default function CoursePage({ params }) {
  const { courseSlug } = params;

  const coursePath = path.join(process.cwd(), "courses", courseSlug, "course.json");

  if (!fs.existsSync(coursePath)) {
    return (
      <div className="p-10 text-red-400 text-xl">
        Ошибка: курс {courseSlug} не найден.
      </div>
    );
  }

  const raw = fs.readFileSync(coursePath, "utf8");
  const course = JSON.parse(raw);

  return (
    <div className="max-w-4xl mx-auto py-16 px-6">
      <h1 className="text-3xl font-bold text-slate-100 mb-10">
        {course.title}
      </h1>

      <p className="text-slate-400 mb-8">{course.description}</p>

      <div className="space-y-4">
        {course.lessons.map((lesson) => (
          <Link
            key={lesson.id}
            href={`/courses/${courseSlug}/lessons/${lesson.id}`}
            className="block p-4 rounded-xl bg-slate-900 border border-slate-800 hover:border-orange-500 transition"
          >
            <div className="text-lg text-slate-100">{lesson.title}</div>
            <div className="text-sm text-slate-500">{lesson.type}</div>
          </Link>
        ))}
      </div>
    </div>
  );
}
